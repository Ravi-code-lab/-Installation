sudo apt update
sudo apt install openjdk-8-jdk -y
java -version javac -version
sudo apt install ssh
sudo apt install openssh-server openssh-client -y
sudo adduser hdoop
sudo adduser hdoop sudo 
sudo cp -r ./hadoop2.sh /home/hdoop/
sudo cp -r ./hadoop3.sh /home/hdoop/
sudo chmod +777 hadoop-3.3.2.tar.gz
sudo cp -f hadoop-3.3.2.tar.gz  /home/hdoop/
su - hdoop
