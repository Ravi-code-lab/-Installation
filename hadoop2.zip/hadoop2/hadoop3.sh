wget https://dlcdn.apache.org/hadoop/common/hadoop-3.3.2/hadoop-3.3.2.tar.gz
sudo chmod +777 hadoop-3.3.2.tar.gz
sudo tar xzf hadoop-3.3.2.tar.gz
cd ~
echo 'export HADOOP_HOME=/home/hdoop/hadoop-3.3.2
export HADOOP_INSTALL=$HADOOP_HOME/bin/hadoop
export HADOOP_MAPRED_HOME=$HADOOP_HOME
export HADOOP_COMMON_HOME=$HADOOP_HOME
export HADOOP_HDFS_HOME=$HADOOP_HOME
export YARN_HOME=$HADOOP_HOME
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
export PATH=$PATH:$HADOOP_HOME/sbin:$HADOOP_HOME/bin
export HADOOP_OPTS="-Djava.library.path=$HADOOP_HOME/lib/nativ"' >> ~/.bashrc
source ~/.bashrc
sudo sed -i "3 i export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64" /home/hdoop/hadoop-3.3.2/etc/hadoop/hadoop-env.sh
sudo sed -i "20 i <property><name>hadoop.tmp.dir</name><value>/home/hdoop/tmpdata</value><description>A base for other temporary directories.</description></property><property> <name>fs.default.name</name><value>hdfs://localhost:9000</value><description>The name of the default file system></description></property>" /home/hdoop/hadoop-3.3.2/etc/hadoop/core-site.xml
sudo sed -i "20 i <property><name>dfs.data.dir</name><value>/home/hdoop/dfsdata/namenode</value></property><property><name>dfs.data.dir</name><value>/home/hdoop/dfsdata/datanode</value></property><property><name>dfs.replication</name><value>1</value></property>" /home/hdoop/hadoop-3.3.2/etc/hadoop/hdfs-site.xml
sudo sed -i "20 i <property><name>mapreduce.framework.name</name><value>yarn</value></property>" /home/hdoop/hadoop-3.3.2/etc/hadoop/mapred-site.xml
sudo sed -i "18 i <property><name>yarn.nodemanager.aux-services</name><value>mapreduce_shuffle</value></property><property><name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name><value>org.apache.hadoop.mapred.ShuffleHandler</value></property><property><name>yarn.resourcemanager.hostname</name><value>127.0.0.1</value></property><property><name>yarn.acl.enable</name><value>0</value></property><property><name>yarn.nodemanager.env-whitelist</name><value>JAVA_HOME,HADOOP_COMMON_HOME,HADOOP_HDFS_HOME,HADOOP_CONF_DIR,CLASSPATH_PERPEND_DISTCACHE,HADOOP_YARN_HOME,HADOOP_MAPRED_HOME</value></property>" /home/hdoop/hadoop-3.3.2/etc/hadoop/yarn-site.xml
cd ~/
sudo chmod +777 /home/hdoop/hadoop-3.3.2
hdfs namenode -format
cd ~/hadoop-3.3.2/sbin/
./start-dfs.sh
./start-yarn.sh
jps

